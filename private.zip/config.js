const { Intents } = require('discord.js')

module.exports.internal = {
    token: '',
    mongoURL: ''
}

module.exports.intents = [
    Intents.FLAGS.GUILDS,
    Intents.FLAGS.GUILD_PRESENCES,
    Intents.FLAGS.GUILD_MEMBERS,
    Intents.FLAGS.GUILD_EMOJIS_AND_STICKERS,
    Intents.FLAGS.GUILD_VOICE_STATES,
    Intents.FLAGS.GUILD_MESSAGES,
    Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
    Intents.FLAGS.GUILD_MESSAGE_TYPING
]

module.exports.ids = {
    owner: "852657621293858877",
    messages: {
        privatrooms: '950418096588472351'
    },
    guilds: {
        main: '923310513658679316'
    },
    channels: {
        text: {
            privatrooms: '951445336466022450'
        },
        voice: {
            createPrivate: '951445401167343636'
        },
        categories: {
            privatrooms: '951445292954292265'
        }
    }
}

module.exports.permissions = {
    privateroom: {
        creator: {
            CREATE_INSTANT_INVITE: true,
            VIEW_CHANNEL: true,
            CONNECT: true,
            SPEAK: true,
            STREAM: true,
            USE_VAD: true,
            PRIORITY_SPEAKER: true,
            MANAGE_CHANNELS: false,
            MANAGE_ROLES: false,
            MANAGE_WEBHOOKS: false,
            MOVE_MEMBERS: false,
        }
    }
}