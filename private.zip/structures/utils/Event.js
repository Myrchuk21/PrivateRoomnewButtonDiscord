module.exports = class Event {
    constructor(name, options = {}) {
        this.name = name || null
        this.config = options
    }

    async run(bot) {
        // 993...
    }
}